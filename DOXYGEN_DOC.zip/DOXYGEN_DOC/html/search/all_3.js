var searchData=
[
  ['sphere_0',['Sphere',['../struct_sphere.html',1,'']]]
];
