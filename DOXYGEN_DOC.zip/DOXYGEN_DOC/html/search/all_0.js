var searchData=
[
  ['guimyframe1_0',['GUIMyFrame1',['../class_g_u_i_my_frame1.html',1,'GUIMyFrame1'],['../class_g_u_i_my_frame1.html#a2909f85fce7b31039157cffb426c435c',1,'GUIMyFrame1::GUIMyFrame1()']]],
  ['guimyframe1_2eh_1',['GUIMyFrame1.h',['../_g_u_i_my_frame1_8h.html',1,'']]]
];
